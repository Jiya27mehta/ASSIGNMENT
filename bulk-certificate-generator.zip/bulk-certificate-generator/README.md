# Bulk Certificate Generator API

A backend service that accepts **one request containing many recipients**, generates a PDF
certificate for each valid recipient from a single predefined template, tracks progress, and
lets the client retrieve results individually or as a ZIP.

Built with **FastAPI · SQLAlchemy 2 · SQLite (PostgreSQL-ready) · ReportLab · pytest**.

![Sample certificate](docs/sample_certificate.png)

## Features

- **Bulk API** - one `POST` with up to 1000 recipients (configurable), not one call per certificate.
- **Background processing** - `POST` returns `202 Accepted` immediately; a worker pool generates the PDFs.
- **Two-level validation** - bad *request* → `422`; bad *recipient row* → only that row fails, the rest are generated.
- **Failure isolation** - a crash while rendering/saving one certificate never affects the others.
- **Traceable results** - every input row gets a stored outcome (`generated` / `failed` + reason + original position).
- **Progress tracking** - derived live from the database: `total / generated / failed / pending / percent_complete`.
- **Retrieval** - single PDF, or ZIP of the whole job with a `manifest.csv` (including failures).
- **Crash recovery** - jobs interrupted by a restart are re-queued; finished certificates aren't regenerated.
- **Idempotent submissions** - optional `Idempotency-Key` header makes retries safe.
- **Docker, CI (GitHub Actions), linting (ruff), 55 automated tests.**

## Quick start

Requires Python 3.11+.

```bash
git clone <your-repo-url> && cd bulk-certificate-generator
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt                     # or requirements.txt for runtime only

uvicorn app.main:create_app --factory --reload          # or: make run
```

- API: <http://localhost:8000>
- Interactive docs (Swagger UI): <http://localhost:8000/docs>
- Health: <http://localhost:8000/health>

The SQLite database and generated PDFs are created under `./data/` on first start.

### With Docker

```bash
docker compose up --build
```

### Configuration

Environment variables (prefix `CERTGEN_`, or a `.env` file - see `.env.example`):

| Variable | Default | Meaning |
|---|---|---|
| `CERTGEN_DATABASE_URL` | `sqlite:///./data/certgen.db` | Any SQLAlchemy URL (e.g. PostgreSQL) |
| `CERTGEN_STORAGE_DIR` | `./data/certificates` | Where PDFs are written |
| `CERTGEN_MAX_RECIPIENTS_PER_JOB` | `1000` | Hard cap per request |
| `CERTGEN_WORKER_THREADS` | `2` | Concurrent jobs in the worker pool |
| `CERTGEN_PROCESSING_MODE` | `background` | `background` or `sync` (process inside the request) |
| `CERTGEN_LOG_LEVEL` | `INFO` | |

## Running the tests

```bash
pytest            # or: make test
make lint         # ruff
```

The suite covers: job creation, request/recipient validation, PDF generation (text is extracted
back out of the PDFs to prove the recipient data is on the page), status/progress transitions,
single-certificate failure isolation (render *and* storage errors), retrieval (PDF + ZIP),
idempotency, crash recovery, and security helpers (path traversal, CSV injection).

## API usage

### 1. Submit a job

```bash
curl -X POST http://localhost:8000/api/v1/jobs \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: bootcamp-2026-batch-1" \
  -d @samples/request.json
```

```jsonc
{
  "event_name": "Python Bootcamp 2026",      // required, max 150 chars
  "issued_by": "Aereo Academy",              // required, max 150 chars
  "issue_date": "2026-10-11",                // optional, defaults to today (UTC)
  "signatory_name": "Jane Doe",              // optional
  "recipients": [                            // required, 1..1000
    { "name": "Asha Verma", "email": "asha@example.com", "achievement": "Distinction" },
    { "name": "Rahul Nair", "email": "rahul@example.com" }   // achievement is optional
  ]
}
```

Response `202 Accepted`:

```json
{
  "id": "bedc9377-8acf-4b3d-b67a-41176598d684",
  "status": "processing",
  "progress": { "total": 5, "generated": 0, "failed": 2, "pending": 3, "percent_complete": 40.0 },
  "links": {
    "self": "/api/v1/jobs/bedc9377-...",
    "certificates": "/api/v1/jobs/bedc9377-.../certificates",
    "download": "/api/v1/jobs/bedc9377-.../download"
  }
}
```

### 2. Check progress

```bash
curl http://localhost:8000/api/v1/jobs/<job_id>
```

Job `status` values: `pending` → `processing` → `completed` | `completed_with_errors` | `failed`.

### 3. See per-recipient results (successes *and* failures)

```bash
curl "http://localhost:8000/api/v1/jobs/<job_id>/certificates?status=failed"
```

```json
{ "position": 3, "recipient_name": "Broken Row", "status": "failed",
  "error": "email: value is not a valid email address: An email address must have an @-sign." }
```

`position` is the 0-based index in the submitted `recipients` array, so a client can map every
failure back to its input row. Supports `?status=`, `?limit=`, `?offset=`.

### 4. Retrieve certificates

```bash
# one PDF (use download_url from the listing above)
curl -o cert.pdf http://localhost:8000/api/v1/certificates/<certificate_id>/download

# everything generated in the job, as a ZIP (PDFs + manifest.csv)
curl -o certificates.zip http://localhost:8000/api/v1/jobs/<job_id>/download
```

### Endpoint reference

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/v1/jobs` | Submit a bulk job (`202`; `200` on idempotent replay) |
| `GET` | `/api/v1/jobs` | List jobs (paginated, `?status=` filter) |
| `GET` | `/api/v1/jobs/{id}` | Status + progress |
| `GET` | `/api/v1/jobs/{id}/certificates` | Per-recipient results |
| `GET` | `/api/v1/jobs/{id}/download` | ZIP of generated PDFs (`409` while the job is still running) |
| `GET` | `/api/v1/certificates/{id}` | Single certificate metadata |
| `GET` | `/api/v1/certificates/{id}/download` | Single PDF (`409` if pending/failed) |
| `GET` | `/health` | Liveness + DB check |

## Architecture

```
            POST /jobs                         worker thread pool
 client ───────────────▶ API (FastAPI) ──────▶ JobProcessor ──▶ ReportLabRenderer ──▶ LocalStorage (PDF files)
   ▲  202 + job id          │  validate rows        │  one short DB transaction
   │                        ▼                       ▼  per certificate
   └── GET /jobs/{id} ◀── SQL database (jobs, certificates) ◀──┘
```

```
app/
  main.py            app factory, wiring, startup recovery
  config.py          env-based settings
  models.py          Job, Certificate (+ status enums)
  schemas.py         request/response models, text sanitising
  api/               thin HTTP layer (jobs, certificates, deps, serializers)
  services/
    validation.py    per-row validation
    jobs.py          job creation, idempotency, progress queries
    processor.py     generation loop, claiming, finalising, dispatchers, recovery
    pdf.py           certificate template (ReportLab)
    storage.py       file storage abstraction (local disk)
    archive.py       ZIP + manifest builder
tests/               pytest suite
```

## Key design decisions

### Background processing (vs. synchronous)
Generating hundreds of PDFs inside one HTTP request would hold the connection open for
seconds-to-minutes, hit client/proxy timeouts, and lose all work on a dropped connection.
So `POST /jobs` only validates and **persists** the job, then returns `202` and a worker thread
does the generation; the client polls `GET /jobs/{id}`.

I deliberately used an **in-process `ThreadPoolExecutor`** rather than Celery/RQ + Redis: for this
scope it avoids extra infrastructure (one command to run) while still demonstrating the correct
async API shape. Because the database is the source of truth for job state, moving to Celery later
means replacing one class (`BackgroundDispatcher`) - the API, schema and processor don't change.
A `sync` mode (`CERTGEN_PROCESSING_MODE=sync`) exists for debugging and deterministic tests.

### Failure handling
- **Request-level** problems (no recipients, missing event name, > max recipients) → `422`, nothing stored.
- **Recipient-level** problems (invalid email, empty/unrenderable name, duplicate email in the job)
  → stored as a `failed` certificate with a readable reason. The valid rows still generate.
- **Generation-level** problems (renderer or disk error) → caught per certificate, recorded as
  `failed`, loop continues.
- Job outcome: all OK → `completed`; mixed → `completed_with_errors`; none succeeded → `failed`.

### Progress is derived, not stored
Counts come from a `GROUP BY` over certificate rows. There are no counters to keep in sync, so
progress cannot drift even if a worker dies half-way.

### Resilience
- Each certificate is committed in its **own short transaction** → progress is durable and visible
  immediately, and SQLite's single writer is never blocked for long.
- A job is **claimed atomically** (`UPDATE ... WHERE status='pending'`) so it can't run twice.
- On startup, jobs stuck in `processing` (crash/restart) are reset and re-queued; since only
  `pending` certificates are processed, finished work isn't redone.
- PDFs are written **atomically** (temp file + `fsync` + rename), never half-written.

### Idempotency
Clients may send `Idempotency-Key`. Replaying the same key with the same body returns the original
job (`200`); a different body with the same key → `409`. Prevents duplicate jobs on network retries.

### Data model
`jobs` (shared certificate info + lifecycle) 1—N `certificates` (one row per input recipient,
including invalid ones, with `position`, `status`, `error`, storage `file_key`). Indexed on
`(job_id, status)` for the progress query. Enums are stored as plain `VARCHAR` (portable, no
native enum migrations). Timestamps are timezone-aware UTC via a small `TypeDecorator`.

### Security / robustness
- Names are drawn with `drawCentredString` (not markup-based Paragraphs) → no markup injection into PDFs.
- Control/invisible characters are rejected; text is NFC-normalised and whitespace-collapsed.
- Storage keys are server-generated UUIDs; `LocalStorage.path_for` additionally blocks path traversal.
- Download filenames are slugified; `manifest.csv` neutralises spreadsheet formula injection (`=`, `+`, `-`, `@`).
- ZIP is built into a temp **file** (not memory) and deleted after the response is sent.
- Long text auto-shrinks, then wraps, then truncates so it can never overflow the template.

## Known limitations & what I'd do next

- **Single process.** The worker pool lives inside the API process, so run one uvicorn worker
  (the Dockerfile does). For horizontal scale: Celery/RQ/Arq workers + PostgreSQL (`SELECT ... FOR UPDATE SKIP LOCKED`
  or a lease column for claiming) and S3-compatible storage (implement the `Storage` protocol).
- **Fonts.** Built-in PDF fonts cover Latin / Western European text only; names in other scripts
  (e.g. Devanagari, CJK) are rejected per-row with a clear message instead of rendering broken
  glyphs. Fix: embed a Unicode TTF (e.g. Noto Sans) in `pdf.py` and relax `PDF_ENCODING` check.
- **No auth / rate limiting.** Would add API keys or OAuth2 and per-client quotas.
- **Schema migrations.** Tables are created with `create_all`; I'd add Alembic for real deployments.
- **Retention.** No cleanup of old jobs/files yet (a scheduled task would handle it).
