from datetime import date
from io import BytesIO

from pypdf import PdfReader

from app.services.pdf import CertificateData, ReportLabRenderer
from tests.conftest import FlakyRenderer, valid_payload


def _data(**kw) -> CertificateData:
    base = dict(
        recipient_name="Asha Verma",
        event_name="Python Bootcamp 2026",
        issued_by="Aereo Academy",
        issue_date=date(2026, 10, 11),
        certificate_number="CERT-ABCD1234-00001",
    )
    base.update(kw)
    return CertificateData(**base)


def _text(pdf_bytes: bytes) -> str:
    return PdfReader(BytesIO(pdf_bytes)).pages[0].extract_text()


# ---- renderer unit tests ---------------------------------------------------------------


def test_renderer_outputs_valid_single_page_pdf_with_recipient_data():
    pdf = ReportLabRenderer().render(_data(achievement="Distinction", signatory_name="Jane Doe"))

    reader = PdfReader(BytesIO(pdf))
    assert pdf.startswith(b"%PDF")
    assert len(reader.pages) == 1
    text = _text(pdf)
    for expected in (
        "Asha Verma",
        "Python Bootcamp 2026",
        "Distinction",
        "Jane Doe",
        "11 October 2026",
        "CERT-ABCD1234-00001",
    ):
        assert expected in text


def test_renderer_handles_extreme_text_lengths_without_error():
    long_name = "A" * 100
    long_event = "An Extremely Long Event Title " * 5  # 150 chars

    pdf = ReportLabRenderer().render(
        _data(
            recipient_name=long_name,
            event_name=long_event.strip()[:150],
            achievement="B" * 100,
            signatory_name="C" * 100,
        )
    )

    assert len(PdfReader(BytesIO(pdf)).pages) == 1


def test_renderer_escapes_markup_like_text_literally():
    pdf = ReportLabRenderer().render(_data(recipient_name="<b>Bold</b> & <script>"))

    assert "<b>Bold</b> & <script>" in _text(pdf)


def test_renderer_is_deterministic():
    r = ReportLabRenderer()
    assert r.render(_data()) == r.render(_data())


# ---- end-to-end generation -------------------------------------------------------------


def test_every_valid_recipient_gets_a_distinct_pdf_on_disk(client):
    job = client.post("/api/v1/jobs", json=valid_payload(4)).json()
    items = client.get(f"/api/v1/jobs/{job['id']}/certificates").json()["items"]

    assert len(items) == 4
    numbers = {i["certificate_number"] for i in items}
    assert len(numbers) == 4  # unique
    for item in items:
        assert item["status"] == "generated"
        assert item["generated_at"] is not None
        pdf = client.get(item["download_url"]).content
        assert item["recipient_name"] in _text(pdf)


def test_achievement_is_printed_only_when_provided(client):
    payload = valid_payload(
        recipients=[
            {"name": "With Ach", "email": "a@example.com", "achievement": "Top Performer"},
            {"name": "No Ach", "email": "b@example.com"},
        ]
    )
    job = client.post("/api/v1/jobs", json=payload).json()
    items = client.get(f"/api/v1/jobs/{job['id']}/certificates").json()["items"]

    with_ach = _text(client.get(items[0]["download_url"]).content)
    without = _text(client.get(items[1]["download_url"]).content)
    assert "Top Performer" in with_ach
    assert "Top Performer" not in without


# ---- single-certificate failure isolation ----------------------------------------------


def test_one_failing_certificate_does_not_stop_the_rest(make_client):
    client = make_client("sync", renderer=FlakyRenderer({"Person 1"}))

    job = client.post("/api/v1/jobs", json=valid_payload(4)).json()

    assert job["status"] == "completed_with_errors"
    assert job["progress"]["generated"] == 3
    assert job["progress"]["failed"] == 1

    items = client.get(f"/api/v1/jobs/{job['id']}/certificates").json()["items"]
    failed = [i for i in items if i["status"] == "failed"]
    assert len(failed) == 1
    assert failed[0]["recipient_name"] == "Person 1"
    assert "boom for Person 1" in failed[0]["error"]
    assert failed[0]["download_url"] is None
    assert [i["status"] for i in items].count("generated") == 3


def test_job_fails_when_every_certificate_fails(make_client):
    client = make_client("sync", renderer=FlakyRenderer({"Person 0", "Person 1"}))

    job = client.post("/api/v1/jobs", json=valid_payload(2)).json()

    assert job["status"] == "failed"
    assert job["progress"]["generated"] == 0


def test_storage_error_is_isolated_like_render_error(make_client, tmp_path):
    from app.services.storage import LocalStorage

    class BrokenStorage(LocalStorage):
        def save(self, job_id, certificate_id, content):
            if not hasattr(self, "_n"):
                self._n = 0
            self._n += 1
            if self._n == 2:
                raise OSError("disk full")
            return super().save(job_id, certificate_id, content)

    from fastapi.testclient import TestClient

    from app.config import Settings
    from app.main import create_app

    settings = Settings(
        database_url=f"sqlite:///{tmp_path / 's.db'}",
        storage_dir=tmp_path / "s",
        processing_mode="sync",
        log_level="WARNING",
    )
    with TestClient(create_app(settings, storage=BrokenStorage(tmp_path / "s"))) as c:
        job = c.post("/api/v1/jobs", json=valid_payload(3)).json()

    assert job["status"] == "completed_with_errors"
    assert job["progress"] == {
        "total": 3,
        "generated": 2,
        "failed": 1,
        "pending": 0,
        "percent_complete": 100.0,
    }
