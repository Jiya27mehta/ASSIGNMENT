import pytest

from tests.conftest import valid_payload

# ---- request-level validation: whole request rejected, nothing stored -----------------


@pytest.mark.parametrize(
    "mutation",
    [
        {"recipients": []},
        {"event_name": ""},
        {"event_name": "   "},
        {"issued_by": ""},
        {"event_name": "x" * 151},
        {"issue_date": "not-a-date"},
        {"event_name": 123},
        {"unexpected_field": True},
    ],
)
def test_invalid_request_is_rejected_with_422(client, mutation):
    resp = client.post("/api/v1/jobs", json=valid_payload(2, **mutation))

    assert resp.status_code == 422
    assert client.get("/api/v1/jobs").json()["total"] == 0


def test_missing_required_fields_is_422(client):
    assert client.post("/api/v1/jobs", json={}).status_code == 422
    assert (
        client.post("/api/v1/jobs", json={"event_name": "x", "issued_by": "y"}).status_code == 422
    )


def test_too_many_recipients_is_rejected(make_client):
    client = make_client("sync", max_recipients=5)

    ok = client.post("/api/v1/jobs", json=valid_payload(5))
    too_many = client.post("/api/v1/jobs", json=valid_payload(6))

    assert ok.status_code == 202
    assert too_many.status_code == 422
    assert "maximum 5" in too_many.json()["detail"]


# ---- recipient-level validation: bad rows fail individually ----------------------------


def _results(client, job_id):
    return client.get(f"/api/v1/jobs/{job_id}/certificates").json()["items"]


def test_invalid_recipients_fail_individually_and_valid_ones_still_generate(client):
    payload = valid_payload(
        recipients=[
            {"name": "Good One", "email": "good@example.com"},
            {"name": "", "email": "empty-name@example.com"},
            {"name": "Bad Email", "email": "not-an-email"},
            {"email": "no-name@example.com"},
            "just a string",
            {"name": "Also Good", "email": "also@example.com", "achievement": "Distinction"},
        ]
    )

    resp = client.post("/api/v1/jobs", json=payload)

    assert resp.status_code == 202
    job = resp.json()
    assert job["status"] == "completed_with_errors"
    assert job["progress"]["generated"] == 2
    assert job["progress"]["failed"] == 4

    items = _results(client, job["id"])
    assert [i["status"] for i in items] == [
        "generated",
        "failed",
        "failed",
        "failed",
        "failed",
        "generated",
    ]
    assert "name" in items[1]["error"]
    assert "email" in items[2]["error"]
    assert "name: field is required" in items[3]["error"]
    assert "JSON object" in items[4]["error"]
    # position lets the client map a failure back to its input row
    assert [i["position"] for i in items] == [0, 1, 2, 3, 4, 5]


def test_duplicate_email_in_one_job_is_flagged_case_insensitively(client):
    payload = valid_payload(
        recipients=[
            {"name": "First", "email": "same@example.com"},
            {"name": "Second", "email": "SAME@example.com"},
        ]
    )

    job = client.post("/api/v1/jobs", json=payload).json()
    items = _results(client, job["id"])

    assert [i["status"] for i in items] == ["generated", "failed"]
    assert "duplicate email" in items[1]["error"]


@pytest.mark.parametrize(
    "name",
    ["日本語の名前", "Name\x00WithNull", "Zero\u200bWidth", "x" * 101],
)
def test_unrenderable_or_malicious_names_are_rejected_per_row(client, name):
    payload = valid_payload(recipients=[{"name": name, "email": "a@example.com"}])

    job = client.post("/api/v1/jobs", json=payload).json()

    assert job["status"] == "failed"
    assert _results(client, job["id"])[0]["status"] == "failed"


def test_accented_latin_names_are_supported_and_whitespace_is_normalised(client):
    payload = valid_payload(
        recipients=[{"name": "  José   Álvarez-Müller \n", "email": " jose@example.com "}]
    )

    job = client.post("/api/v1/jobs", json=payload).json()
    item = _results(client, job["id"])[0]

    assert item["status"] == "generated"
    assert item["recipient_name"] == "José Álvarez-Müller"
    assert item["recipient_email"] == "jose@example.com"


def test_job_where_every_recipient_is_invalid_is_failed_immediately(make_client):
    # background mode: must not hang waiting for a worker that has nothing to do
    client = make_client("background")
    payload = valid_payload(recipients=[{"name": "", "email": "x"}, 42])

    job = client.post("/api/v1/jobs", json=payload).json()

    assert job["status"] == "failed"
    assert job["finished_at"] is not None
    assert job["progress"]["failed"] == 2
