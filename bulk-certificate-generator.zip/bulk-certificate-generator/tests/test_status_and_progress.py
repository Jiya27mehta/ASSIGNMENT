from app.models import CertificateStatus, Job, JobStatus
from app.schemas import JobCreate
from app.services.jobs import create_job
from app.services.processor import recover_incomplete_jobs
from tests.conftest import GatedRenderer, valid_payload, wait_for_status


def test_status_transitions_pending_processing_completed(make_client):
    renderer = GatedRenderer()
    client = make_client("background", renderer=renderer)

    job = client.post("/api/v1/jobs", json=valid_payload(3)).json()
    in_flight = wait_for_status(client, job["id"], {"processing"})

    # Worker is blocked inside the first certificate: nothing finished yet.
    assert in_flight["started_at"] is not None
    assert in_flight["finished_at"] is None
    assert in_flight["progress"]["generated"] == 0
    assert in_flight["progress"]["pending"] == 3
    assert in_flight["progress"]["percent_complete"] == 0.0

    renderer.release.set()
    done = wait_for_status(client, job["id"], {"completed"})
    assert done["progress"]["percent_complete"] == 100.0
    assert done["finished_at"] is not None


def test_progress_counts_add_up_for_mixed_outcomes(client):
    payload = valid_payload(
        recipients=[
            {"name": "A", "email": "a@example.com"},
            {"name": "B", "email": "bad"},
            {"name": "C", "email": "c@example.com"},
            {"name": "D", "email": "d@example.com"},
        ]
    )
    job = client.post("/api/v1/jobs", json=payload).json()
    p = job["progress"]

    assert p["generated"] + p["failed"] + p["pending"] == p["total"] == 4
    assert (p["generated"], p["failed"]) == (3, 1)
    assert p["percent_complete"] == 100.0


def test_certificates_endpoint_filters_and_paginates(client):
    payload = valid_payload(
        recipients=[{"name": f"P{i}", "email": f"p{i}@example.com"} for i in range(5)]
        + [{"name": "", "email": "bad"}]
    )
    job = client.post("/api/v1/jobs", json=payload).json()
    url = f"/api/v1/jobs/{job['id']}/certificates"

    assert client.get(url, params={"status": "failed"}).json()["total"] == 1
    page = client.get(url, params={"limit": 2, "offset": 2}).json()
    assert page["total"] == 6
    assert [i["position"] for i in page["items"]] == [2, 3]
    assert client.get(url, params={"status": "bogus"}).status_code == 422


def test_interrupted_job_is_recovered_without_regenerating_finished_work(make_client):
    client = make_client("sync")
    sf = client.app.state.session_factory

    # Simulate a crash: a job stuck in "processing" with one cert done, two still pending.
    with sf() as db:
        job, _ = create_job(db, JobCreate(**valid_payload(3)))
        job_id = job.id
        job.status = JobStatus.PROCESSING
        db.commit()
    first_cert_id = None
    with sf() as db:
        certs = db.get(Job, job_id).certificates
        first_cert_id = certs[0].id
        key = client.app.state.storage.save(job_id, certs[0].id, b"%PDF-existing")
        certs[0].status = CertificateStatus.GENERATED
        certs[0].file_key = key
        db.commit()

    recovered = recover_incomplete_jobs(sf, client.app.state.dispatcher.dispatch)

    assert recovered == 1
    body = client.get(f"/api/v1/jobs/{job_id}").json()
    assert body["status"] == "completed"
    assert body["progress"]["generated"] == 3
    # the already-finished certificate was left untouched, not regenerated
    kept = client.app.state.storage.path_for(f"{job_id}/{first_cert_id}.pdf").read_bytes()
    assert kept == b"%PDF-existing"
