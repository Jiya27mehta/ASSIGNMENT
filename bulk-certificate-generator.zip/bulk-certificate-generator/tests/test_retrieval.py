import csv
import io
import zipfile

import pytest

from app.services.archive import csv_safe, safe_filename
from app.services.storage import LocalStorage
from tests.conftest import FlakyRenderer, GatedRenderer, valid_payload, wait_for_status


def test_download_single_certificate_as_pdf(client):
    job = client.post("/api/v1/jobs", json=valid_payload(1)).json()
    item = client.get(f"/api/v1/jobs/{job['id']}/certificates").json()["items"][0]

    resp = client.get(item["download_url"])

    assert resp.status_code == 200
    assert resp.headers["content-type"] == "application/pdf"
    assert resp.content.startswith(b"%PDF")
    assert item["certificate_number"] in resp.headers["content-disposition"]


def test_certificate_metadata_endpoint(client):
    job = client.post("/api/v1/jobs", json=valid_payload(1)).json()
    item = client.get(f"/api/v1/jobs/{job['id']}/certificates").json()["items"][0]

    meta = client.get(f"/api/v1/certificates/{item['id']}").json()

    assert meta["recipient_email"] == "person0@example.com"
    assert meta["status"] == "generated"


def test_downloading_a_failed_certificate_is_409_with_reason(make_client):
    client = make_client("sync", renderer=FlakyRenderer({"Person 0"}))
    job = client.post("/api/v1/jobs", json=valid_payload(2)).json()
    items = client.get(f"/api/v1/jobs/{job['id']}/certificates").json()["items"]

    resp = client.get(f"/api/v1/certificates/{items[0]['id']}/download")

    assert resp.status_code == 409
    assert "boom" in resp.json()["detail"]


def test_unknown_certificate_is_404(client):
    missing = "00000000-0000-0000-0000-000000000000"
    assert client.get(f"/api/v1/certificates/{missing}").status_code == 404
    assert client.get(f"/api/v1/certificates/{missing}/download").status_code == 404


def test_missing_file_on_disk_is_reported_not_crashed(client):
    job = client.post("/api/v1/jobs", json=valid_payload(1)).json()
    item = client.get(f"/api/v1/jobs/{job['id']}/certificates").json()["items"][0]
    with client.app.state.session_factory() as db:
        from app.models import Certificate

        key = db.get(Certificate, item["id"]).file_key
    client.app.state.storage.path_for(key).unlink()

    assert client.get(item["download_url"]).status_code == 404


def test_zip_contains_all_generated_pdfs_and_manifest(make_client):
    client = make_client("sync", renderer=FlakyRenderer({"Person 1"}))
    payload = valid_payload(
        recipients=[
            {"name": "Person 0", "email": "p0@example.com"},
            {"name": "Person 1", "email": "p1@example.com"},  # render fails
            {"name": "Person 2", "email": "oops"},  # validation fails
            {"name": "Person 3", "email": "p3@example.com"},
        ]
    )
    job = client.post("/api/v1/jobs", json=payload).json()

    resp = client.get(job["links"]["download"])

    assert resp.status_code == 200
    assert resp.headers["content-type"] == "application/zip"
    zf = zipfile.ZipFile(io.BytesIO(resp.content))
    names = zf.namelist()
    pdfs = [n for n in names if n.endswith(".pdf")]
    assert len(pdfs) == 2 and "manifest.csv" in names
    assert all(zf.read(n).startswith(b"%PDF") for n in pdfs)

    rows = list(csv.DictReader(io.StringIO(zf.read("manifest.csv").decode())))
    assert [r["status"] for r in rows] == ["generated", "failed", "failed", "generated"]
    assert rows[1]["error"].startswith("Generation failed")
    assert rows[2]["file"] == ""


def test_zip_is_409_while_job_is_still_running(make_client):
    renderer = GatedRenderer()
    client = make_client("background", renderer=renderer)
    job = client.post("/api/v1/jobs", json=valid_payload(2)).json()
    wait_for_status(client, job["id"], {"processing"})

    resp = client.get(job["links"]["download"])

    assert resp.status_code == 409
    renderer.release.set()
    wait_for_status(client, job["id"], {"completed"})
    assert client.get(job["links"]["download"]).status_code == 200


def test_zip_of_fully_failed_job_is_404(client):
    job = client.post(
        "/api/v1/jobs", json=valid_payload(recipients=[{"name": "", "email": "x"}])
    ).json()

    assert client.get(job["links"]["download"]).status_code == 404


def test_zip_temp_file_is_cleaned_up(client, tmp_path, monkeypatch):
    import glob
    import os
    import tempfile

    monkeypatch.setattr(tempfile, "tempdir", str(tmp_path / "tmp"))
    os.makedirs(tmp_path / "tmp")
    job = client.post("/api/v1/jobs", json=valid_payload(2)).json()

    client.get(job["links"]["download"])

    assert glob.glob(str(tmp_path / "tmp" / "certs_*.zip")) == []


# ---- security helpers ------------------------------------------------------------------


def test_storage_rejects_path_traversal(tmp_path):
    storage = LocalStorage(tmp_path / "root")
    with pytest.raises(ValueError):
        storage.path_for("../../etc/passwd")


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("Asha Verma", "Asha_Verma"),
        ("../../etc/passwd", "etc_passwd"),
        ("José Ñ", "Jose_N"),
        ("", "certificate"),
    ],
)
def test_safe_filename(raw, expected):
    assert safe_filename(raw) == expected


def test_csv_formula_injection_is_neutralised():
    assert csv_safe("=HYPERLINK('http://evil')") == "'=HYPERLINK('http://evil')"
    assert csv_safe("+1") == "'+1"
    assert csv_safe("Normal Name") == "Normal Name"


def test_health_endpoint(client):
    assert client.get("/health").json() == {"status": "ok"}
