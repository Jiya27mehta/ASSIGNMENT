from tests.conftest import valid_payload, wait_for_status


def test_create_job_returns_202_and_job_resource(client):
    resp = client.post("/api/v1/jobs", json=valid_payload(3))

    assert resp.status_code == 202
    body = resp.json()
    assert body["id"]
    assert body["event_name"] == "Python Bootcamp 2026"
    assert body["progress"]["total"] == 3
    assert body["links"]["self"] == f"/api/v1/jobs/{body['id']}"


def test_bulk_job_with_many_recipients_in_one_request(client):
    resp = client.post("/api/v1/jobs", json=valid_payload(150))

    assert resp.status_code == 202
    body = resp.json()
    assert body["status"] == "completed"
    assert body["progress"] == {
        "total": 150,
        "generated": 150,
        "failed": 0,
        "pending": 0,
        "percent_complete": 100.0,
    }


def test_background_mode_returns_before_work_is_done(make_client):
    from tests.conftest import GatedRenderer

    renderer = GatedRenderer()
    client = make_client("background", renderer=renderer)

    resp = client.post("/api/v1/jobs", json=valid_payload(2))

    assert resp.status_code == 202
    assert resp.json()["status"] in {"pending", "processing"}  # not finished yet
    renderer.release.set()
    wait_for_status(client, resp.json()["id"], {"completed"})


def test_issue_date_defaults_to_today(client):
    payload = valid_payload(1)
    del payload["issue_date"]

    body = client.post("/api/v1/jobs", json=payload).json()

    assert body["issue_date"]  # filled in by the server


def test_idempotency_key_replay_returns_same_job(client):
    headers = {"Idempotency-Key": "abc-123"}
    first = client.post("/api/v1/jobs", json=valid_payload(2), headers=headers)
    second = client.post("/api/v1/jobs", json=valid_payload(2), headers=headers)

    assert first.status_code == 202
    assert second.status_code == 200
    assert first.json()["id"] == second.json()["id"]
    assert client.get("/api/v1/jobs").json()["total"] == 1


def test_idempotency_key_with_different_body_is_conflict(client):
    headers = {"Idempotency-Key": "abc-123"}
    client.post("/api/v1/jobs", json=valid_payload(2), headers=headers)
    resp = client.post("/api/v1/jobs", json=valid_payload(3), headers=headers)

    assert resp.status_code == 409


def test_unknown_job_is_404_and_bad_uuid_is_422(client):
    assert client.get("/api/v1/jobs/00000000-0000-0000-0000-000000000000").status_code == 404
    assert client.get("/api/v1/jobs/not-a-uuid").status_code == 422


def test_list_jobs_pagination_and_status_filter(client):
    for _ in range(3):
        client.post("/api/v1/jobs", json=valid_payload(1))
    bad = valid_payload(1, recipients=[{"name": "", "email": "nope"}])
    client.post("/api/v1/jobs", json=bad)

    page = client.get("/api/v1/jobs", params={"limit": 2}).json()
    assert page["total"] == 4 and len(page["items"]) == 2

    failed = client.get("/api/v1/jobs", params={"status": "failed"}).json()
    assert failed["total"] == 1
