import threading
import time
from collections.abc import Callable

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app
from app.services.pdf import CertificateData, CertificateRenderer, ReportLabRenderer


class FlakyRenderer:
    """Delegates to the real renderer but raises for chosen recipient names."""

    def __init__(self, fail_for: set[str]):
        self.fail_for = fail_for
        self._real = ReportLabRenderer()

    def render(self, data: CertificateData) -> bytes:
        if data.recipient_name in self.fail_for:
            raise RuntimeError(f"boom for {data.recipient_name}")
        return self._real.render(data)


class GatedRenderer:
    """Blocks every render until ``release`` is set - lets tests observe a running job."""

    def __init__(self):
        self.release = threading.Event()
        self._real = ReportLabRenderer()

    def render(self, data: CertificateData) -> bytes:
        assert self.release.wait(timeout=10), "test never released the renderer"
        return self._real.render(data)


@pytest.fixture
def make_client(tmp_path) -> Callable[..., TestClient]:
    """Factory: ``make_client(mode="sync", renderer=..., max_recipients=...)``."""
    created: list[TestClient] = []

    def _make(
        mode: str = "sync",
        renderer: CertificateRenderer | None = None,
        max_recipients: int = 1000,
    ) -> TestClient:
        settings = Settings(
            database_url=f"sqlite:///{tmp_path / 'test.db'}",
            storage_dir=tmp_path / "files",
            processing_mode=mode,
            max_recipients_per_job=max_recipients,
            worker_threads=2,
            log_level="WARNING",
        )
        client = TestClient(create_app(settings, renderer=renderer))
        client.__enter__()  # run lifespan (startup recovery / shutdown)
        created.append(client)
        return client

    yield _make
    for c in created:
        c.__exit__(None, None, None)


@pytest.fixture
def client(make_client) -> TestClient:
    return make_client("sync")


def valid_payload(n: int = 3, **overrides) -> dict:
    payload = {
        "event_name": "Python Bootcamp 2026",
        "issued_by": "Aereo Academy",
        "issue_date": "2026-10-11",
        "signatory_name": "Jane Doe",
        "recipients": [
            {"name": f"Person {i}", "email": f"person{i}@example.com"} for i in range(n)
        ],
    }
    payload.update(overrides)
    return payload


@pytest.fixture
def payload_factory():
    return valid_payload


def wait_for_status(client: TestClient, job_id: str, wanted: set[str], timeout: float = 10) -> dict:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        body = client.get(f"/api/v1/jobs/{job_id}").json()
        if body["status"] in wanted:
            return body
        time.sleep(0.02)
    raise AssertionError(f"job {job_id} never reached {wanted}; last={body}")
