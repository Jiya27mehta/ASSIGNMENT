# Interview cheat-sheet (for the author)

You must be able to explain and modify this code. Read this once, then read the code.

## 60-second pitch
"It's a FastAPI service. `POST /jobs` validates the request, stores a job plus one row per
recipient (invalid rows are stored as failed with a reason), returns 202, and a background worker
generates a PDF per pending row. Each certificate is its own try/except and its own DB
transaction, so one failure never blocks the others. Progress is computed from the rows with a
GROUP BY. Clients poll the job and download single PDFs or a ZIP."

## Where to look in the code
| Question | File |
|---|---|
| How is a job created? | `services/jobs.py::create_job` |
| Where does isolation of one failure happen? | `services/processor.py::_generate_one` |
| How do I know job status at the end? | `processor.py::_finalize` |
| What happens on a crash? | `processor.py::recover_incomplete_jobs` |
| Where's the PDF layout? | `services/pdf.py` |
| How is invalid row handling done? | `services/validation.py` |

## Likely questions
- **Why background and not sync?** Request timeouts, lost work on disconnect, can't show progress. Sync mode still exists for tests.
- **Why not Celery?** Scope/infra tradeoff; the dispatcher is an interface so it's a one-class swap. Be honest about the single-process limitation.
- **Why store invalid rows?** Every input row gets a traceable outcome; client can fix & resubmit just those.
- **Why derive progress rather than keep counters?** No drift, no lost updates under concurrency.
- **What if two workers pick the same job?** Atomic `UPDATE ... WHERE status='pending'` claim; only one gets `rowcount == 1`.
- **What if the server dies mid-job?** Startup recovery resets `processing` -> `pending`; only pending certificates are redone.
- **Why SQLite?** Zero setup; URL is configurable, nothing is SQLite-specific except WAL pragmas.

## Practice modifications (changed-requirement drills)
1. *Add a `template` field with two designs* -> add column on `Job`, pass to `CertificateData`, branch in `ReportLabRenderer`.
2. *Add retry for failed certificates* -> new endpoint `POST /jobs/{id}/retry` that sets FAILED (non-validation) rows back to PENDING, sets job PENDING, dispatches.
3. *Email each certificate* -> after `GENERATED`, enqueue a send step; add `emailed_at` column.
4. *Cap per-user usage* -> add `client_id` to `Job`, count recent jobs in the route.
5. *Support Hindi names* -> embed a Noto Sans Devanagari TTF in `pdf.py`, relax `clean_printable`.
6. *Cancel a job* -> add `CANCELLED` status; processor checks job status between certificates.
