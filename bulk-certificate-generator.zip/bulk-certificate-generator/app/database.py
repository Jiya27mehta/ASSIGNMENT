"""Database engine / session factory helpers."""

from collections.abc import Callable

from sqlalchemy import Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker

SessionFactory = Callable[[], Session]


def make_engine(database_url: str) -> Engine:
    is_sqlite = database_url.startswith("sqlite")
    kwargs: dict = {"pool_pre_ping": True}
    if is_sqlite:
        # Worker threads and request threads each use their own Session, so sharing the
        # underlying connection pool across threads is safe.
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}

    engine = create_engine(database_url, **kwargs)

    if is_sqlite:

        @event.listens_for(engine, "connect")
        def _sqlite_pragmas(dbapi_conn, _record):  # pragma: no cover - trivial
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL")  # readers don't block the writer
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.close()

    return engine


def make_session_factory(engine: Engine) -> sessionmaker[Session]:
    # expire_on_commit=False: objects stay usable after commit without a refresh query.
    return sessionmaker(bind=engine, expire_on_commit=False, autoflush=False)
