"""/api/v1/certificates endpoints (single certificate)."""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.api.deps import get_db, get_storage
from app.api.serializers import certificate_to_out
from app.models import Certificate, CertificateStatus
from app.schemas import CertificateOut
from app.services.archive import pdf_filename
from app.services.storage import Storage

router = APIRouter(prefix="/certificates", tags=["certificates"])


def _get_or_404(db: Session, certificate_id: UUID) -> Certificate:
    cert = db.get(Certificate, str(certificate_id))
    if cert is None:
        raise HTTPException(status_code=404, detail="Certificate not found")
    return cert


@router.get("/{certificate_id}", response_model=CertificateOut, summary="Certificate metadata")
def get_certificate(
    certificate_id: UUID, db: Annotated[Session, Depends(get_db)]
) -> CertificateOut:
    return certificate_to_out(_get_or_404(db, certificate_id))


@router.get(
    "/{certificate_id}/download",
    summary="Download one certificate as PDF",
    response_class=FileResponse,
    responses={200: {"content": {"application/pdf": {}}}},
)
def download_certificate(
    certificate_id: UUID,
    db: Annotated[Session, Depends(get_db)],
    storage: Annotated[Storage, Depends(get_storage)],
) -> FileResponse:
    cert = _get_or_404(db, certificate_id)

    if cert.status == CertificateStatus.PENDING:
        raise HTTPException(status_code=409, detail="Certificate has not been generated yet")
    if cert.status == CertificateStatus.FAILED or not cert.file_key:
        raise HTTPException(
            status_code=409,
            detail=f"Certificate generation failed: {cert.error or 'unknown error'}",
        )
    if not storage.exists(cert.file_key):
        raise HTTPException(status_code=404, detail="Certificate file is missing from storage")

    return FileResponse(
        storage.path_for(cert.file_key),
        media_type="application/pdf",
        filename=pdf_filename(cert),
    )
