"""FastAPI dependencies. All shared objects hang off ``app.state`` (set in create_app)."""

from collections.abc import Iterator

from fastapi import Request
from sqlalchemy.orm import Session

from app.config import Settings
from app.services.processor import Dispatcher
from app.services.storage import Storage


def get_db(request: Request) -> Iterator[Session]:
    with request.app.state.session_factory() as session:
        yield session


def get_settings_dep(request: Request) -> Settings:
    return request.app.state.settings


def get_storage(request: Request) -> Storage:
    return request.app.state.storage


def get_dispatcher(request: Request) -> Dispatcher:
    return request.app.state.dispatcher
