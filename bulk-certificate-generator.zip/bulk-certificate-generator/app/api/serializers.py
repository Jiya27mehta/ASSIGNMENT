"""ORM -> response model mapping."""

from app.models import Certificate, CertificateStatus, Job
from app.schemas import CertificateOut, JobLinks, JobOut, Progress

API_PREFIX = "/api/v1"


def job_to_out(job: Job, progress: Progress) -> JobOut:
    base = f"{API_PREFIX}/jobs/{job.id}"
    return JobOut(
        id=job.id,
        status=job.status,
        event_name=job.event_name,
        issued_by=job.issued_by,
        issue_date=job.issue_date,
        signatory_name=job.signatory_name,
        progress=progress,
        created_at=job.created_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
        links=JobLinks(self=base, certificates=f"{base}/certificates", download=f"{base}/download"),
    )


def certificate_to_out(cert: Certificate) -> CertificateOut:
    generated = cert.status == CertificateStatus.GENERATED
    return CertificateOut(
        id=cert.id,
        job_id=cert.job_id,
        position=cert.position,
        recipient_name=cert.recipient_name,
        recipient_email=cert.recipient_email,
        achievement=cert.achievement,
        certificate_number=cert.certificate_number,
        status=cert.status,
        error=cert.error,
        generated_at=cert.generated_at,
        download_url=f"{API_PREFIX}/certificates/{cert.id}/download" if generated else None,
    )
