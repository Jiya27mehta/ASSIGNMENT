"""/api/v1/jobs endpoints."""

import os
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Response
from fastapi.responses import FileResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from starlette.background import BackgroundTask

from app.api.deps import get_db, get_dispatcher, get_settings_dep, get_storage
from app.api.serializers import certificate_to_out, job_to_out
from app.config import Settings
from app.models import Certificate, CertificateStatus, Job, JobStatus
from app.schemas import CertificateList, JobCreate, JobList, JobOut
from app.services import jobs as job_service
from app.services.archive import build_job_archive
from app.services.processor import Dispatcher
from app.services.storage import Storage

router = APIRouter(prefix="/jobs", tags=["jobs"])


def _get_job_or_404(db: Session, job_id: UUID) -> Job:
    job = db.get(Job, str(job_id))
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post(
    "",
    response_model=JobOut,
    status_code=202,
    summary="Submit a bulk certificate generation job",
    responses={
        200: {"description": "Idempotent replay: the job for this Idempotency-Key already exists"},
        409: {"description": "Idempotency-Key reused with a different request body"},
        422: {"description": "Request-level validation error (nothing was stored)"},
    },
)
def create_job(
    payload: JobCreate,
    response: Response,
    db: Annotated[Session, Depends(get_db)],
    settings: Annotated[Settings, Depends(get_settings_dep)],
    dispatcher: Annotated[Dispatcher, Depends(get_dispatcher)],
    idempotency_key: Annotated[str | None, Header(min_length=1, max_length=128)] = None,
) -> JobOut:
    """Accepts up to `max_recipients_per_job` recipients in one request.

    Invalid recipients do **not** reject the request: they are recorded as `failed`
    certificates (with a reason) while all valid ones are generated.
    """
    if len(payload.recipients) > settings.max_recipients_per_job:
        raise HTTPException(
            status_code=422,
            detail=f"Too many recipients: {len(payload.recipients)} "
            f"(maximum {settings.max_recipients_per_job} per job). Split into several jobs.",
        )

    try:
        job, created = job_service.create_job(db, payload, idempotency_key)
    except job_service.IdempotencyConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    if not created:
        response.status_code = 200
    elif job.status == JobStatus.PENDING:
        # Only enqueue *after* the commit inside create_job, otherwise the worker could
        # look for a job that is not visible yet.
        dispatcher.dispatch(job.id)

    db.expire_all()  # re-read: in sync mode the job has already progressed
    job = db.get(Job, job.id)
    return job_to_out(job, job_service.progress_for_jobs(db, [job])[job.id])


@router.get("", response_model=JobList, summary="List jobs (newest first)")
def list_jobs(
    db: Annotated[Session, Depends(get_db)],
    status: JobStatus | None = None,
    limit: Annotated[int, Query(ge=1, le=100)] = 20,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> JobList:
    base = select(Job)
    count_q = select(func.count()).select_from(Job)
    if status:
        base = base.where(Job.status == status)
        count_q = count_q.where(Job.status == status)

    total = db.scalar(count_q) or 0
    jobs = list(db.scalars(base.order_by(Job.created_at.desc()).limit(limit).offset(offset)))
    progress = job_service.progress_for_jobs(db, jobs)
    return JobList(
        total=total,
        limit=limit,
        offset=offset,
        items=[job_to_out(j, progress[j.id]) for j in jobs],
    )


@router.get("/{job_id}", response_model=JobOut, summary="Job status and progress")
def get_job(job_id: UUID, db: Annotated[Session, Depends(get_db)]) -> JobOut:
    job = _get_job_or_404(db, job_id)
    return job_to_out(job, job_service.progress_for_jobs(db, [job])[job.id])


@router.get(
    "/{job_id}/certificates",
    response_model=CertificateList,
    summary="Per-recipient results of a job (successes and failures)",
)
def list_job_certificates(
    job_id: UUID,
    db: Annotated[Session, Depends(get_db)],
    status: CertificateStatus | None = None,
    limit: Annotated[int, Query(ge=1, le=500)] = 100,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> CertificateList:
    job = _get_job_or_404(db, job_id)
    where = [Certificate.job_id == job.id]
    if status:
        where.append(Certificate.status == status)

    total = db.scalar(select(func.count()).select_from(Certificate).where(*where)) or 0
    certs = db.scalars(
        select(Certificate).where(*where).order_by(Certificate.position).limit(limit).offset(offset)
    )
    return CertificateList(
        total=total, limit=limit, offset=offset, items=[certificate_to_out(c) for c in certs]
    )


@router.get(
    "/{job_id}/download",
    summary="Download all generated certificates of a finished job as a ZIP",
    response_class=FileResponse,
    responses={
        200: {"content": {"application/zip": {}}},
        409: {"description": "Job is still pending/processing"},
    },
)
def download_job_archive(
    job_id: UUID,
    db: Annotated[Session, Depends(get_db)],
    storage: Annotated[Storage, Depends(get_storage)],
) -> FileResponse:
    job = _get_job_or_404(db, job_id)
    if not job.status.is_terminal:
        raise HTTPException(
            status_code=409,
            detail=f"Job is {job.status.value}; try again when it has finished",
        )

    certs = list(
        db.scalars(
            select(Certificate).where(Certificate.job_id == job.id).order_by(Certificate.position)
        )
    )
    if not any(c.status == CertificateStatus.GENERATED for c in certs):
        raise HTTPException(status_code=404, detail="Job has no generated certificates")

    archive_path = build_job_archive(certs, storage)
    return FileResponse(
        archive_path,
        media_type="application/zip",
        filename=f"certificates_{job.id}.zip",
        background=BackgroundTask(os.unlink, archive_path),  # remove temp file after sending
    )
