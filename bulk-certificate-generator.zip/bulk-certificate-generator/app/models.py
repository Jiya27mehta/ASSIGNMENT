"""SQLAlchemy ORM models."""

import enum
import uuid
from datetime import UTC, date, datetime

from sqlalchemy import (
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import TypeDecorator


def utcnow() -> datetime:
    return datetime.now(UTC)


def new_id() -> str:
    return str(uuid.uuid4())


class UTCDateTime(TypeDecorator):
    """Stores timezone-aware datetimes as naive UTC and restores tzinfo on load.

    SQLite (and ``TIMESTAMP WITHOUT TIME ZONE`` on Postgres) would otherwise silently
    drop tzinfo, which leads to naive/aware comparison bugs.
    """

    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("Naive datetime not allowed; use timezone-aware UTC datetimes")
        return value.astimezone(UTC).replace(tzinfo=None)

    def process_result_value(self, value, dialect):
        return value.replace(tzinfo=UTC) if value is not None else None


class Base(DeclarativeBase):
    pass


class JobStatus(enum.StrEnum):
    PENDING = "pending"  # accepted, waiting for a worker
    PROCESSING = "processing"  # a worker is generating certificates
    COMPLETED = "completed"  # every certificate generated
    COMPLETED_WITH_ERRORS = "completed_with_errors"  # some generated, some failed
    FAILED = "failed"  # nothing could be generated

    @property
    def is_terminal(self) -> bool:
        return self in {JobStatus.COMPLETED, JobStatus.COMPLETED_WITH_ERRORS, JobStatus.FAILED}


class CertificateStatus(enum.StrEnum):
    PENDING = "pending"
    GENERATED = "generated"
    FAILED = "failed"


def _enum_col(enum_cls: type[enum.Enum]) -> Enum:
    # Store the lowercase *values* (portable VARCHAR, no native DB enum to migrate).
    return Enum(
        enum_cls,
        values_callable=lambda e: [m.value for m in e],
        native_enum=False,
        length=32,
        validate_strings=True,
    )


class Job(Base):
    """One bulk-generation request."""

    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)

    # Optional client-supplied key making POST /jobs safe to retry.
    idempotency_key: Mapped[str | None] = mapped_column(String(128), unique=True)
    request_hash: Mapped[str | None] = mapped_column(String(64))

    # Certificate-level information shared by every recipient in the job.
    event_name: Mapped[str] = mapped_column(String(150))
    issued_by: Mapped[str] = mapped_column(String(150))
    issue_date: Mapped[date] = mapped_column(Date)
    signatory_name: Mapped[str | None] = mapped_column(String(100))

    status: Mapped[JobStatus] = mapped_column(
        _enum_col(JobStatus), default=JobStatus.PENDING, index=True
    )
    total_count: Mapped[int] = mapped_column(Integer, default=0)

    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime)

    certificates: Mapped[list["Certificate"]] = relationship(
        back_populates="job", cascade="all, delete-orphan", order_by="Certificate.position"
    )


class Certificate(Base):
    """One recipient row of a job. Exists for valid *and* invalid rows so every input row
    has a traceable outcome (generated / failed + reason)."""

    __tablename__ = "certificates"
    __table_args__ = (
        UniqueConstraint("job_id", "position", name="uq_certificate_job_position"),
        Index("ix_certificates_job_status", "job_id", "status"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"))
    position: Mapped[int] = mapped_column(Integer)  # 0-based index in the request

    # Nullable / lenient on purpose: invalid rows are stored as received (truncated).
    recipient_name: Mapped[str | None] = mapped_column(String(320))
    recipient_email: Mapped[str | None] = mapped_column(String(320))
    achievement: Mapped[str | None] = mapped_column(String(200))

    certificate_number: Mapped[str] = mapped_column(String(64), unique=True)
    status: Mapped[CertificateStatus] = mapped_column(
        _enum_col(CertificateStatus), default=CertificateStatus.PENDING
    )
    error: Mapped[str | None] = mapped_column(Text)
    file_key: Mapped[str | None] = mapped_column(String(512))  # storage key, never a user path
    generated_at: Mapped[datetime | None] = mapped_column(UTCDateTime)

    job: Mapped[Job] = relationship(back_populates="certificates")
