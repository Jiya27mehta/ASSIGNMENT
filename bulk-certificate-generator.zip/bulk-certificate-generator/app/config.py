"""Application settings, loaded from environment variables (prefix ``CERTGEN_``)."""

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="CERTGEN_", extra="ignore")

    database_url: str = "sqlite:///./data/certgen.db"
    storage_dir: Path = Path("./data/certificates")

    # Hard cap on recipients per request: protects memory, DB and request latency.
    max_recipients_per_job: int = Field(default=1000, ge=1)

    # Size of the in-process worker pool (each worker handles one job at a time).
    worker_threads: int = Field(default=2, ge=1)

    # "background": POST returns 202 immediately, a worker thread does the work.
    # "sync": the job is processed inside the request (used by most tests).
    processing_mode: Literal["background", "sync"] = "background"

    log_level: str = "INFO"


@lru_cache
def get_settings() -> Settings:
    return Settings()
