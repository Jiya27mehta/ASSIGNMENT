"""Application factory. Run with: ``uvicorn app.main:create_app --factory``."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import text

from app.api import certificates, jobs
from app.api.serializers import API_PREFIX
from app.config import Settings, get_settings
from app.database import make_engine, make_session_factory
from app.models import Base
from app.services.pdf import CertificateRenderer, ReportLabRenderer
from app.services.processor import (
    BackgroundDispatcher,
    JobProcessor,
    SyncDispatcher,
    recover_incomplete_jobs,
)
from app.services.storage import LocalStorage, Storage

log = logging.getLogger(__name__)


def create_app(
    settings: Settings | None = None,
    *,
    renderer: CertificateRenderer | None = None,
    storage: Storage | None = None,
) -> FastAPI:
    """Build the app. ``renderer`` / ``storage`` can be injected (used heavily by tests)."""
    settings = settings or get_settings()
    logging.basicConfig(
        level=settings.log_level.upper(),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )

    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)  # swap for Alembic migrations in a larger system
    session_factory = make_session_factory(engine)

    storage = storage or LocalStorage(settings.storage_dir)
    renderer = renderer or ReportLabRenderer()
    processor = JobProcessor(session_factory, storage, renderer)
    dispatcher = (
        SyncDispatcher(processor)
        if settings.processing_mode == "sync"
        else BackgroundDispatcher(processor, settings.worker_threads)
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Pick up jobs interrupted by a previous crash/restart.
        recover_incomplete_jobs(session_factory, dispatcher.dispatch)
        yield
        dispatcher.shutdown()
        engine.dispose()

    app = FastAPI(
        title="Bulk Certificate Generator API",
        version="1.0.0",
        description=(
            "Submit one request with many recipients, track progress, and download the "
            "generated PDF certificates individually or as a ZIP."
        ),
        lifespan=lifespan,
    )
    app.state.settings = settings
    app.state.session_factory = session_factory
    app.state.storage = storage
    app.state.renderer = renderer
    app.state.processor = processor
    app.state.dispatcher = dispatcher
    app.state.engine = engine

    app.include_router(jobs.router, prefix=API_PREFIX)
    app.include_router(certificates.router, prefix=API_PREFIX)

    @app.get("/health", tags=["meta"], summary="Liveness + DB connectivity check")
    def health() -> dict:
        with session_factory() as db:
            db.execute(text("SELECT 1"))
        return {"status": "ok"}

    return app
