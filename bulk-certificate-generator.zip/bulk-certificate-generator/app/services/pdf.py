"""PDF rendering of the (single, predefined) certificate template.

The renderer is a small class behind a ``Protocol`` so the processor does not depend on
ReportLab, and tests can inject a renderer that fails on demand.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from io import BytesIO
from typing import Protocol

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import simpleSplit
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen.canvas import Canvas

NAVY = HexColor("#1B2A49")
GOLD = HexColor("#B8923A")
GREY = HexColor("#5B6475")


@dataclass(frozen=True)
class CertificateData:
    recipient_name: str
    event_name: str
    issued_by: str
    issue_date: date
    certificate_number: str
    achievement: str | None = None
    signatory_name: str | None = None


class CertificateRenderer(Protocol):
    def render(self, data: CertificateData) -> bytes: ...


class ReportLabRenderer:
    PAGE_W, PAGE_H = landscape(A4)  # 841.9 x 595.3 pt

    def render(self, data: CertificateData) -> bytes:
        buf = BytesIO()
        # invariant=1 -> no timestamps/random IDs: identical input gives identical bytes.
        c = Canvas(buf, pagesize=landscape(A4), invariant=1)
        c.setTitle(f"Certificate - {data.recipient_name}")
        c.setAuthor(data.issued_by)
        c.setSubject(data.event_name)

        self._draw_border(c)
        self._draw_body(c, data)
        c.showPage()
        c.save()
        return buf.getvalue()

    # -- drawing helpers ---------------------------------------------------------------

    def _draw_border(self, c: Canvas) -> None:
        w, h = self.PAGE_W, self.PAGE_H
        c.setStrokeColor(NAVY)
        c.setLineWidth(6)
        c.rect(24, 24, w - 48, h - 48)
        c.setStrokeColor(GOLD)
        c.setLineWidth(1.5)
        c.rect(36, 36, w - 72, h - 72)

    def _draw_body(self, c: Canvas, d: CertificateData) -> None:
        w, h = self.PAGE_W, self.PAGE_H
        cx = w / 2
        max_w = w - 200

        c.setFillColor(NAVY)
        c.setFont("Helvetica-Bold", 38)
        c.drawCentredString(cx, h - 120, "CERTIFICATE")
        c.setFillColor(GOLD)
        c.setFont("Helvetica", 15)
        c.drawCentredString(cx, h - 148, "OF  ACHIEVEMENT" if d.achievement else "OF  COMPLETION")

        c.setStrokeColor(GOLD)
        c.setLineWidth(1)
        c.line(cx - 90, h - 165, cx + 90, h - 165)

        c.setFillColor(GREY)
        c.setFont("Helvetica", 14)
        c.drawCentredString(cx, h - 205, "This is to certify that")

        c.setFillColor(NAVY)
        y = self._fitted(c, d.recipient_name, cx, h - 255, "Helvetica-Bold", 40, 18, max_w, 2)

        c.setFillColor(GREY)
        c.setFont("Helvetica", 14)
        c.drawCentredString(cx, y - 30, "has successfully completed")

        c.setFillColor(NAVY)
        y = self._fitted(c, d.event_name, cx, y - 66, "Helvetica-Bold", 24, 14, max_w, 2)

        if d.achievement:
            c.setFillColor(GOLD)
            y = self._fitted(c, d.achievement, cx, y - 30, "Helvetica-Oblique", 16, 11, max_w, 1)

        self._draw_footer(c, d)

    def _draw_footer(self, c: Canvas, d: CertificateData) -> None:
        w = self.PAGE_W
        base_y = 100

        # left: date
        c.setStrokeColor(NAVY)
        c.setLineWidth(0.8)
        c.line(90, base_y, 280, base_y)
        c.setFillColor(NAVY)
        c.setFont("Helvetica", 12)
        c.drawCentredString(185, base_y + 6, d.issue_date.strftime("%d %B %Y"))
        c.setFillColor(GREY)
        c.setFont("Helvetica", 10)
        c.drawCentredString(185, base_y - 14, "DATE")

        # right: signatory + issuer
        c.setStrokeColor(NAVY)
        c.line(w - 340, base_y, w - 90, base_y)
        c.setFillColor(NAVY)
        sig = d.signatory_name or d.issued_by
        self._fitted(c, sig, w - 215, base_y + 6, "Helvetica", 12, 8, 240, 1)
        c.setFillColor(GREY)
        c.setFont("Helvetica", 10)
        label = "AUTHORISED SIGNATORY" if d.signatory_name else "ISSUED BY"
        c.drawCentredString(w - 215, base_y - 14, label)

        # centre: issuer + certificate number
        c.setFillColor(GREY)
        c.setFont("Helvetica", 9)
        c.drawCentredString(
            w / 2, 58, f"Issued by {d.issued_by}"[:120] + "  |  " + d.certificate_number
        )

    @staticmethod
    def _fitted(
        c: Canvas,
        text: str,
        cx: float,
        y: float,
        font: str,
        max_size: float,
        min_size: float,
        max_width: float,
        max_lines: int,
    ) -> float:
        """Draw centred text that always fits: shrink first, then wrap, then truncate.

        Returns the y of the last drawn baseline so callers can stack content below.
        """
        size = max_size
        while size >= min_size:
            if stringWidth(text, font, size) <= max_width:
                c.setFont(font, size)
                c.drawCentredString(cx, y, text)
                return y

            size -= 1

        # Still too wide at the minimum size -> wrap, truncating the final line if needed.
        lines = simpleSplit(text, font, min_size, max_width)
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            last = lines[-1]
            while last and stringWidth(last + "...", font, min_size) > max_width:
                last = last[:-1]
            lines[-1] = last.rstrip() + "..."

        c.setFont(font, min_size)
        line_height = min_size * 1.25
        for i, line in enumerate(lines):
            c.drawCentredString(cx, y - i * line_height, line)
        return y - (len(lines) - 1) * line_height
