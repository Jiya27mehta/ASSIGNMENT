"""Build a ZIP with every generated certificate of a job plus a CSV manifest."""

from __future__ import annotations

import csv
import io
import os
import re
import tempfile
import unicodedata
import zipfile
from pathlib import Path

from app.models import Certificate, CertificateStatus
from app.services.storage import Storage

_CSV_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def safe_filename(name: str, fallback: str = "certificate") -> str:
    """ASCII-only, filesystem/header-safe slug."""
    ascii_name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    slug = re.sub(r"[^A-Za-z0-9]+", "_", ascii_name).strip("_")
    return slug[:60] or fallback


def csv_safe(value: str | None) -> str:
    """Neutralise spreadsheet formula injection (a name like ``=HYPERLINK(...)``)."""
    if not value:
        return ""
    return "'" + value if value.startswith(_CSV_FORMULA_PREFIXES) else value


def pdf_filename(cert: Certificate) -> str:
    return f"{cert.certificate_number}_{safe_filename(cert.recipient_name or '')}.pdf"


def build_job_archive(certificates: list[Certificate], storage: Storage) -> Path:
    """Write the ZIP to a temp file (not memory) and return its path.

    The caller is responsible for deleting the file after sending it.
    """
    fd, tmp_name = tempfile.mkstemp(prefix="certs_", suffix=".zip")
    os.close(fd)
    path = Path(tmp_name)

    manifest = io.StringIO()
    writer = csv.writer(manifest)
    writer.writerow(["position", "certificate_number", "name", "email", "status", "file", "error"])

    try:
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for cert in certificates:
                filename = ""
                if cert.status == CertificateStatus.GENERATED and cert.file_key:
                    if storage.exists(cert.file_key):
                        filename = pdf_filename(cert)
                        zf.write(storage.path_for(cert.file_key), arcname=filename)
                    else:  # DB says generated but the file vanished: be honest in the manifest
                        filename = ""
                writer.writerow(
                    [
                        cert.position,
                        cert.certificate_number,
                        csv_safe(cert.recipient_name),
                        csv_safe(cert.recipient_email),
                        cert.status.value,
                        filename,
                        csv_safe(cert.error),
                    ]
                )
            zf.writestr("manifest.csv", manifest.getvalue())
    except BaseException:
        path.unlink(missing_ok=True)
        raise
    return path
