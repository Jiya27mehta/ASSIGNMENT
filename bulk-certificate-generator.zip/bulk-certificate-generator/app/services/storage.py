"""File storage abstraction.

Only this module knows certificates live on a local disk. Swapping in S3/GCS means
implementing the same three methods. Database rows store an opaque *storage key*
(``<job_id>/<certificate_id>.pdf``) - never a path derived from user input.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Protocol


class Storage(Protocol):
    def save(self, job_id: str, certificate_id: str, content: bytes) -> str: ...
    def path_for(self, key: str) -> Path: ...
    def exists(self, key: str) -> bool: ...


class LocalStorage:
    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, job_id: str, certificate_id: str, content: bytes) -> str:
        key = f"{job_id}/{certificate_id}.pdf"
        target = self.path_for(key)
        target.parent.mkdir(parents=True, exist_ok=True)

        # Atomic write: a reader (or a crash) never observes a half-written PDF.
        fd, tmp_name = tempfile.mkstemp(dir=target.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(content)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp_name, target)
        except BaseException:
            Path(tmp_name).unlink(missing_ok=True)
            raise
        return key

    def path_for(self, key: str) -> Path:
        path = (self.root / key).resolve()
        # Defence in depth against path traversal (keys are server-generated, but still).
        if not path.is_relative_to(self.root):
            raise ValueError("Invalid storage key")
        return path

    def exists(self, key: str) -> bool:
        return self.path_for(key).is_file()
