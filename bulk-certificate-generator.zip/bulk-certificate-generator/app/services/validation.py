"""Per-recipient validation.

Every input row yields a ``ValidatedRow`` - either with a clean ``RecipientIn`` or with a
human-readable ``error``. Nothing here raises for bad data; callers decide what to do.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pydantic import ValidationError

from app.schemas import RecipientIn


@dataclass(frozen=True)
class ValidatedRow:
    position: int
    recipient: RecipientIn | None
    error: str | None
    # Best-effort raw values so failed rows can be shown back to the client.
    raw_name: str | None
    raw_email: str | None
    raw_achievement: str | None


def _as_text(value: Any, limit: int) -> str | None:
    if value is None:
        return None
    return str(value)[:limit]


def _format_errors(exc: ValidationError) -> str:
    parts = []
    for err in exc.errors():
        field = ".".join(str(p) for p in err["loc"]) or "recipient"
        msg = err["msg"].removeprefix("Value error, ")
        if err["type"] == "missing":
            msg = "field is required"
        parts.append(f"{field}: {msg}")
    return "; ".join(parts)


def validate_recipients(raw_recipients: list[Any]) -> list[ValidatedRow]:
    rows: list[ValidatedRow] = []
    seen_emails: dict[str, int] = {}

    for position, raw in enumerate(raw_recipients):
        if not isinstance(raw, dict):
            rows.append(
                ValidatedRow(position, None, "recipient must be a JSON object", None, None, None)
            )
            continue

        raw_name = _as_text(raw.get("name"), 320)
        raw_email = _as_text(raw.get("email"), 320)
        raw_ach = _as_text(raw.get("achievement"), 200)

        try:
            recipient = RecipientIn.model_validate(raw)
        except ValidationError as exc:
            rows.append(
                ValidatedRow(position, None, _format_errors(exc), raw_name, raw_email, raw_ach)
            )
            continue

        # The same person twice in one job almost always means a pasted-twice CSV.
        key = recipient.email.lower()
        if key in seen_emails:
            rows.append(
                ValidatedRow(
                    position,
                    None,
                    f"duplicate email (already used by recipient at position {seen_emails[key]})",
                    raw_name,
                    raw_email,
                    raw_ach,
                )
            )
            continue

        seen_emails[key] = position
        rows.append(ValidatedRow(position, recipient, None, raw_name, raw_email, raw_ach))

    return rows
