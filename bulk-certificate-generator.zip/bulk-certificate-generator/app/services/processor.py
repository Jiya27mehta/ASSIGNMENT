"""Job processing: turns PENDING certificate rows into PDFs.

Design notes
------------
* **Failure isolation** - every certificate is processed in its own try/except and its
  own short DB transaction. One failing certificate is recorded and the loop moves on.
* **Crash safety / resumability** - progress is committed per certificate and the
  processor only picks up rows still in ``PENDING``. If the process dies mid-job, the job
  can simply be processed again (see ``recover_incomplete_jobs``); finished certificates
  are not regenerated.
* **No long-lived transaction** - a job with 1000 certificates never holds one DB
  transaction open (important for SQLite's single writer).
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Protocol

from sqlalchemy import func, select, update

from app.database import SessionFactory
from app.models import Certificate, CertificateStatus, Job, JobStatus, utcnow
from app.services.pdf import CertificateData, CertificateRenderer
from app.services.storage import Storage

log = logging.getLogger(__name__)

MAX_ERROR_LENGTH = 500


class JobProcessor:
    def __init__(
        self,
        session_factory: SessionFactory,
        storage: Storage,
        renderer: CertificateRenderer,
    ) -> None:
        self._sf = session_factory
        self._storage = storage
        self._renderer = renderer

    # ---------------------------------------------------------------------- public API

    def process(self, job_id: str) -> None:
        """Generate all pending certificates of a job. Never raises."""
        try:
            self._process(job_id)
        except Exception:  # last line of defence: a bad job must not kill the worker
            log.exception("Unexpected error while processing job %s", job_id)

    # --------------------------------------------------------------------- internals

    def _process(self, job_id: str) -> None:
        if not self._claim(job_id):
            log.info("Job %s not claimable (already running or finished) - skipping", job_id)
            return

        with self._sf() as db:
            job = db.get(Job, job_id)
            assert job is not None
            job_info = (job.event_name, job.issued_by, job.issue_date, job.signatory_name)
            pending_ids = list(
                db.scalars(
                    select(Certificate.id)
                    .where(
                        Certificate.job_id == job_id,
                        Certificate.status == CertificateStatus.PENDING,
                    )
                    .order_by(Certificate.position)
                )
            )

        log.info("Job %s: generating %d certificates", job_id, len(pending_ids))
        for cert_id in pending_ids:
            try:
                self._generate_one(cert_id, job_info)
            except Exception:
                # e.g. the DB itself failed while recording the outcome.
                log.exception("Could not record outcome for certificate %s", cert_id)

        self._finalize(job_id)

    def _claim(self, job_id: str) -> bool:
        """Atomically move PENDING -> PROCESSING so one job never runs twice at once."""
        with self._sf() as db:
            result = db.execute(
                update(Job)
                .where(Job.id == job_id, Job.status == JobStatus.PENDING)
                .values(status=JobStatus.PROCESSING, started_at=utcnow())
            )
            db.commit()
            return result.rowcount == 1

    def _generate_one(self, cert_id: str, job_info: tuple) -> None:
        event_name, issued_by, issue_date, signatory = job_info

        with self._sf() as db:
            cert = db.get(Certificate, cert_id)
            if cert is None or cert.status != CertificateStatus.PENDING:
                return

            try:
                pdf_bytes = self._renderer.render(
                    CertificateData(
                        recipient_name=cert.recipient_name or "",
                        event_name=event_name,
                        issued_by=issued_by,
                        issue_date=issue_date,
                        certificate_number=cert.certificate_number,
                        achievement=cert.achievement,
                        signatory_name=signatory,
                    )
                )
                key = self._storage.save(cert.job_id, cert.id, pdf_bytes)
            except Exception as exc:
                log.warning("Certificate %s failed: %s", cert_id, exc, exc_info=True)
                cert.status = CertificateStatus.FAILED
                cert.error = f"Generation failed: {type(exc).__name__}: {exc}"[:MAX_ERROR_LENGTH]
            else:
                cert.status = CertificateStatus.GENERATED
                cert.file_key = key
                cert.generated_at = utcnow()
                cert.error = None

            db.commit()

    def _finalize(self, job_id: str) -> None:
        with self._sf() as db:
            # Anything still pending here means we could not record its outcome above.
            db.execute(
                update(Certificate)
                .where(
                    Certificate.job_id == job_id,
                    Certificate.status == CertificateStatus.PENDING,
                )
                .values(status=CertificateStatus.FAILED, error="Internal error: not processed")
            )
            counts = dict(
                db.execute(
                    select(Certificate.status, func.count())
                    .where(Certificate.job_id == job_id)
                    .group_by(Certificate.status)
                ).all()
            )
            generated = counts.get(CertificateStatus.GENERATED, 0)
            failed = counts.get(CertificateStatus.FAILED, 0)

            if failed == 0:
                status = JobStatus.COMPLETED
            elif generated == 0:
                status = JobStatus.FAILED
            else:
                status = JobStatus.COMPLETED_WITH_ERRORS

            db.execute(
                update(Job).where(Job.id == job_id).values(status=status, finished_at=utcnow())
            )
            db.commit()
            log.info(
                "Job %s finished: status=%s generated=%d failed=%d",
                job_id,
                status.value,
                generated,
                failed,
            )


# ------------------------------------------------------------------------- dispatching


class Dispatcher(Protocol):
    def dispatch(self, job_id: str) -> None: ...
    def shutdown(self) -> None: ...


class SyncDispatcher:
    """Runs the job inline (inside the HTTP request). Simple and deterministic."""

    def __init__(self, processor: JobProcessor) -> None:
        self._processor = processor

    def dispatch(self, job_id: str) -> None:
        self._processor.process(job_id)

    def shutdown(self) -> None:
        pass


class BackgroundDispatcher:
    """Hands the job to an in-process thread pool and returns immediately."""

    def __init__(self, processor: JobProcessor, max_workers: int) -> None:
        self._processor = processor
        self._pool = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="certgen")

    def dispatch(self, job_id: str) -> None:
        self._pool.submit(self._processor.process, job_id)

    def shutdown(self) -> None:
        # Don't block shutdown on queued jobs; they are re-queued on next startup.
        self._pool.shutdown(wait=False, cancel_futures=True)


def recover_incomplete_jobs(
    session_factory: SessionFactory, dispatch: Callable[[str], None]
) -> int:
    """Re-queue jobs that were interrupted by a restart/crash.

    A job left in ``processing`` has no live worker anymore, so it is reset to ``pending``
    and queued again. Because the processor only touches ``PENDING`` certificates, work
    that was already finished is kept.
    """
    with session_factory() as db:
        db.execute(
            update(Job).where(Job.status == JobStatus.PROCESSING).values(status=JobStatus.PENDING)
        )
        db.commit()
        job_ids = list(
            db.scalars(
                select(Job.id).where(Job.status == JobStatus.PENDING).order_by(Job.created_at)
            )
        )

    for job_id in job_ids:
        dispatch(job_id)
    if job_ids:
        log.info("Recovered %d interrupted job(s)", len(job_ids))
    return len(job_ids)
