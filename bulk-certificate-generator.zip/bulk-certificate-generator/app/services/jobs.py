"""Job creation and query logic (no HTTP concerns in here)."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import Certificate, CertificateStatus, Job, JobStatus, new_id, utcnow
from app.schemas import JobCreate, Progress
from app.services.validation import validate_recipients


class IdempotencyConflict(Exception):
    """Same Idempotency-Key reused with a different request body."""


def _fingerprint(payload: JobCreate) -> str:
    canonical = json.dumps(payload.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


def create_job(
    db: Session, payload: JobCreate, idempotency_key: str | None = None
) -> tuple[Job, bool]:
    """Validate recipients and persist the job + one row per recipient.

    Returns ``(job, created)``; ``created`` is False when an idempotent replay returned an
    already existing job. Invalid recipients are stored as FAILED rows (with the reason)
    instead of rejecting the request, so every input row has a traceable outcome.
    """
    fingerprint = _fingerprint(payload)

    if idempotency_key:
        existing = db.scalar(select(Job).where(Job.idempotency_key == idempotency_key))
        if existing:
            return _replay(existing, fingerprint), False

    rows = validate_recipients(payload.recipients)
    invalid = sum(1 for r in rows if r.error)

    job = Job(
        id=new_id(),
        idempotency_key=idempotency_key,
        request_hash=fingerprint,
        event_name=payload.event_name,
        issued_by=payload.issued_by,
        issue_date=payload.issue_date or utcnow().date(),
        signatory_name=payload.signatory_name,
        total_count=len(rows),
    )
    # Every row failed validation -> nothing to process, the job is already final.
    if invalid == len(rows):
        job.status = JobStatus.FAILED
        job.finished_at = utcnow()

    number_prefix = job.id.replace("-", "")[:8].upper()
    for row in rows:
        r = row.recipient
        job.certificates.append(
            Certificate(
                position=row.position,
                recipient_name=r.name if r else row.raw_name,
                recipient_email=str(r.email) if r else row.raw_email,
                achievement=r.achievement if r else row.raw_achievement,
                certificate_number=f"CERT-{number_prefix}-{row.position + 1:05d}",
                status=CertificateStatus.FAILED if row.error else CertificateStatus.PENDING,
                error=row.error,
            )
        )

    db.add(job)
    try:
        db.commit()
    except IntegrityError:
        # Two concurrent requests with the same Idempotency-Key: the loser replays.
        db.rollback()
        if idempotency_key:
            existing = db.scalar(select(Job).where(Job.idempotency_key == idempotency_key))
            if existing:
                return _replay(existing, fingerprint), False
        raise
    return job, True


def _replay(existing: Job, fingerprint: str) -> Job:
    if existing.request_hash != fingerprint:
        raise IdempotencyConflict("Idempotency-Key was already used with a different request body")
    return existing


# ---------------------------------------------------------------------------- queries


def progress_for_jobs(db: Session, jobs: Iterable[Job]) -> dict[str, Progress]:
    """Progress is *derived* from certificate rows (one GROUP BY), never stored as a
    counter, so it can't drift out of sync under concurrent workers."""
    jobs = list(jobs)
    if not jobs:
        return {}
    ids = [j.id for j in jobs]
    counts: dict[str, dict[CertificateStatus, int]] = {j.id: {} for j in jobs}
    q = (
        select(Certificate.job_id, Certificate.status, func.count())
        .where(Certificate.job_id.in_(ids))
        .group_by(Certificate.job_id, Certificate.status)
    )
    for job_id, status, n in db.execute(q):
        counts[job_id][status] = n

    result = {}
    for job in jobs:
        c = counts[job.id]
        generated = c.get(CertificateStatus.GENERATED, 0)
        failed = c.get(CertificateStatus.FAILED, 0)
        pending = c.get(CertificateStatus.PENDING, 0)
        total = job.total_count
        done = generated + failed
        result[job.id] = Progress(
            total=total,
            generated=generated,
            failed=failed,
            pending=pending,
            percent_complete=round(done / total * 100, 1) if total else 100.0,
        )
    return result
