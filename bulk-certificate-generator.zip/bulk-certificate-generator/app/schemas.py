"""Pydantic request/response schemas.

Validation is deliberately split in two levels:

* **Request level** (``JobCreate``): problems that make the whole request meaningless
  (missing event name, empty recipient list, ...) -> HTTP 422, nothing is stored.
* **Recipient level** (``RecipientIn``): validated one row at a time in
  ``services.validation`` so a single bad row never rejects the other 999.
"""

from __future__ import annotations

import unicodedata
from datetime import date, datetime
from typing import Annotated, Any

from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    StringConstraints,
    field_validator,
)

from app.models import CertificateStatus, JobStatus

# The built-in PDF fonts only cover Windows-1252 (Latin). Rather than silently printing
# "?" boxes on a certificate, text outside this range is rejected up front with a clear
# message. See README -> "Known limitations".
PDF_ENCODING = "cp1252"


def clean_printable(value: str, field_label: str) -> str:
    value = unicodedata.normalize("NFC", value).strip()
    # Collapse internal whitespace runs (also removes newlines/tabs).
    value = " ".join(value.split())
    if any(unicodedata.category(ch).startswith("C") for ch in value):
        raise ValueError(f"{field_label} contains control or invisible characters")
    try:
        value.encode(PDF_ENCODING)
    except UnicodeEncodeError as exc:
        bad = value[exc.start]
        raise ValueError(
            f"{field_label} contains unsupported character {bad!r} "
            "(only Latin/Western European characters can be rendered)"
        ) from None
    return value


# ----------------------------------------------------------------------------- requests


class RecipientIn(BaseModel):
    """A single recipient. Validated per row, see services.validation."""

    model_config = ConfigDict(extra="ignore")

    name: Annotated[str, StringConstraints(min_length=1, max_length=100)]
    email: EmailStr
    achievement: Annotated[str, StringConstraints(max_length=100)] | None = None

    @field_validator("name", mode="before")
    @classmethod
    def _clean_name(cls, v: Any) -> Any:
        if not isinstance(v, str):
            raise ValueError("name must be a string")
        return clean_printable(v, "name")

    @field_validator("achievement", mode="before")
    @classmethod
    def _clean_achievement(cls, v: Any) -> Any:
        if v is None:
            return None
        if not isinstance(v, str):
            raise ValueError("achievement must be a string")
        return clean_printable(v, "achievement") or None

    @field_validator("email", mode="before")
    @classmethod
    def _strip_email(cls, v: Any) -> Any:
        return v.strip() if isinstance(v, str) else v


class JobCreate(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "event_name": "Python Bootcamp 2026",
                "issued_by": "Aereo Academy",
                "issue_date": "2026-10-11",
                "signatory_name": "Jane Doe",
                "recipients": [
                    {
                        "name": "Asha Verma",
                        "email": "asha@example.com",
                        "achievement": "Distinction",
                    },
                    {"name": "Rahul Nair", "email": "rahul@example.com"},
                ],
            }
        },
    )

    event_name: Annotated[str, StringConstraints(min_length=1, max_length=150)]
    issued_by: Annotated[str, StringConstraints(min_length=1, max_length=150)]
    issue_date: date | None = Field(default=None, description="Defaults to today (UTC)")
    signatory_name: Annotated[str, StringConstraints(max_length=100)] | None = None
    # Items are intentionally untyped here; each is validated individually so one bad
    # row doesn't reject the entire request. The max size is enforced against settings
    # in the route (it is configurable).
    recipients: Annotated[list[Any], Field(min_length=1)]

    @field_validator("event_name", "issued_by", mode="before")
    @classmethod
    def _clean_required_text(cls, v: Any, info) -> Any:
        if not isinstance(v, str):
            raise ValueError(f"{info.field_name} must be a string")
        return clean_printable(v, info.field_name)

    @field_validator("signatory_name", mode="before")
    @classmethod
    def _clean_optional_text(cls, v: Any) -> Any:
        if v is None:
            return None
        if not isinstance(v, str):
            raise ValueError("signatory_name must be a string")
        return clean_printable(v, "signatory_name") or None


# ---------------------------------------------------------------------------- responses


class Progress(BaseModel):
    total: int
    generated: int
    failed: int
    pending: int
    percent_complete: float = Field(description="(generated + failed) / total * 100")


class JobLinks(BaseModel):
    self: str
    certificates: str
    download: str


class JobOut(BaseModel):
    id: str
    status: JobStatus
    event_name: str
    issued_by: str
    issue_date: date
    signatory_name: str | None
    progress: Progress
    created_at: datetime
    started_at: datetime | None
    finished_at: datetime | None
    links: JobLinks


class JobList(BaseModel):
    total: int
    limit: int
    offset: int
    items: list[JobOut]


class CertificateOut(BaseModel):
    id: str
    job_id: str
    position: int = Field(description="0-based index of this recipient in the request")
    recipient_name: str | None
    recipient_email: str | None
    achievement: str | None
    certificate_number: str
    status: CertificateStatus
    error: str | None
    generated_at: datetime | None
    download_url: str | None = Field(description="Present only when status == generated")


class CertificateList(BaseModel):
    total: int
    limit: int
    offset: int
    items: list[CertificateOut]
